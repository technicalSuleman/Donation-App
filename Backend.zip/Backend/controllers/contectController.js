const Contact = require('../models/Contect');
const nodemailer = require('nodemailer');

const transporter = nodemailer.createTransport({
    service: 'gmail',
    auth: {
        user: 'suleman.khan4340@gmail.com',  
        pass: 'wgkt hxdn deoe nyed'    
    }
});
exports.submitContactForm = async (req, res) => {
    try {
        const { name, email, phone, subject, message } = req.body;
 
        if (!name || !email || !phone || !subject || !message) {
            return res.status(400).json({ error: "All fields are required." });
        }

        const newContact = new Contact({ name, email, phone, subject, message });
        await newContact.save();

        const mailOptions = {
            from: 'your-email@gmail.com',  
            to: 'suleman.khan4340@gmail.com',  
            subject: `${subject}`,
            text: `
                Name: ${name}
                Email: ${email}
                Phone: ${phone}
                Subject: ${subject}
                Message: ${message}
            `
        };

        transporter.sendMail(mailOptions, (error, info) => {
            if (error) {
                console.error("Error sending email:", error);
                return res.status(500).json({ error: "Email sending failed" });
            }
            console.log("Email sent:", info.response);
        });

        res.status(201).json({ message: "Form submitted successfully! Email sent." });
    } catch (error) {
        console.error("Error saving contact form:", error);
        res.status(500).json({ error: "Server error" });
    }
};
