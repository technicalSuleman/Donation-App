const Stripe = require("stripe");
const stripe = new Stripe("sk_test_51QtXOpED3lpf5Po36IclR9XFD2sVcs1GgAsACpS0fFSLOkJbZSABXHfcSpl7JWjVBtVcW4ltpmJ7jIzOrgvT8Iw700YdESlXxI");

exports.processPayment = async (req, res) => {
  try {
    const { amount, cardNumber, expMonth, expYear, cvv } = req.body;

    // Create a payment method
    const paymentMethod = await stripe.paymentMethods.create({
      type: "card",
      card: {
        number: cardNumber,
        exp_month: expMonth,
        exp_year: expYear,
        cvc: cvv,
      },
    });

    // Create a payment intent
    const paymentIntent = await stripe.paymentIntents.create({
      amount: amount * 100, // Convert to cents
      currency: "usd",
      payment_method: paymentMethod.id,
      confirm: true,
    });

    res.status(200).json({ success: true, message: "Payment Successful", paymentIntent });
  } catch (error) {
    res.status(500).json({ success: false, message: error.message });
  }
};
