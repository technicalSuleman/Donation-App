const express = require("express");
const Blog = require("../models/Blog");
const router = express.Router();

// Get All Blogs
router.get("/", async (req, res) => {
  try {
    const blogs = await Blog.find();
    res.json(blogs);
  } catch (error) {
    res.status(500).json({ error: "Error fetching blogs" });
  }
});

// Like a blog
router.put("/like/:id", async (req, res) => {
  try {
    const blog = await Blog.findById(req.params.id);
    if (!blog) return res.status(404).json({ error: "Blog not found" });

    blog.likes += 1;
    await blog.save();
    res.json(blog);
  } catch (error) {
    res.status(500).json({ error: "Error liking blog" });
  }
});

// Add Comment to a Blog
router.post("/comment/:id", async (req, res) => {
  try {
    const blog = await Blog.findById(req.params.id);
    if (!blog) return res.status(404).json({ error: "Blog not found" });

    blog.comments.push({ text: req.body.text });
    await blog.save();
    res.json(blog);
  } catch (error) {
    res.status(500).json({ error: "Error adding comment" });
  }
});

module.exports = router;
