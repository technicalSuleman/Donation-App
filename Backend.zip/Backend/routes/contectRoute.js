const express = require('express');
const router = express.Router();
const { submitContactForm } = require('../controllers/contectController');

router.post('/submit', submitContactForm);

module.exports = router;
