const mongoose = require("mongoose");

const BlogSchema = new mongoose.Schema({
  title: String,
  description: String,
  image: String,
  date: String,
  likes: { type: Number, default: 0 },
  comments: [{ text: String, date: { type: Date, default: Date.now } }],
});

module.exports = mongoose.model("blog", BlogSchema);
