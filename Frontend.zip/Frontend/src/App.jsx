import React from "react";
import "bootstrap/dist/css/bootstrap.min.css";
import "./App.css";
import { BrowserRouter as Router, Route, Routes, useLocation } from "react-router-dom";

import Banner from "./component/banner/Banner";
import Index from "./component/Home/Index";
import About from "./Pages/about/About";
import Navbar from "./component/Home/Navbar";
import Cause from "./Pages/cause/CausePage";
import Donate from "./Pages/donate/Donate";
import Contact from "./Pages/contect/Contect"; // Fixed typo
import Blog from "./Pages/blog/Blog";
import DonationPage from "./component/cause details/DonationPage"; // Added missing import

function App() {
  return (
    <Router>
      <ConditionalNavbar />
      <Routes>
        <Route path="/" element={<Banner />} />
        <Route path="/home" element={<Index />} />
        <Route path="/cause" element={<Cause />} />
        <Route path="/blog" element={<Blog />} />
        <Route path="/about" element={<About />} />
        <Route path="/contact" element={<Contact />} />
        <Route path="/donate/:id" element={<DonationPage />} />
        <Route path="/donate" element={<Donate />} />
      </Routes>
    </Router>
  );
}

function ConditionalNavbar() {
  const location = useLocation();
  const noNavbarRoutes = ["/"]; // Hide Navbar only on the homepage
  return noNavbarRoutes.includes(location.pathname) ? null : <Navbar />;
}

export default App;
