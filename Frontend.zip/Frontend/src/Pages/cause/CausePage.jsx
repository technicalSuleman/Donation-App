import React from 'react'
import './style.css'
import AboutHeader from '../../component/about_header/AboutHeader'
import Cause from '../../component/cause/Cause'
import Footer from '../../component/footer/Footer'

function CausePage() {
  return (
    <div style={{overflow: "hidden",height: "100vh", width: "100%",overflowY: "scroll"}}>
      <AboutHeader />
      <Cause />
      <Footer />
    </div>
  )
}

export default CausePage
