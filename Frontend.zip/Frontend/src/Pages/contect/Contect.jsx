import React from 'react'
import './style.css'
import Contect_heder from '../../component/contect header/Contect_heder'
import ContactUsForm from '../../component/contect us/ContactUsForm'
import Contect_Hero from '../../component/contect us/Contect_Hero'
import FAQ from '../../component/contect us/Faq'
import Footer from '../../component/footer/Footer'

function Contect() {
  return (
    <div>
      <Contect_heder />
      <ContactUsForm />
      <Contect_Hero />
      <FAQ />
      <Footer />
    </div>
  )
}

export default Contect
