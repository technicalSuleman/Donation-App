import React from 'react';
import Footer from '../../component/footer/Footer'
import './style.css';
import Donate_header from './Donate_header';
import Form from '../../component/Form/Form';

function Donation() {
  return (
    <div>
      <Donate_header />
      <Form />
      <Footer />
    </div>
  );
}

export default Donation;
