import React from 'react'
import './style.css'

function Donate_header() {
  return (
    <div>
      <header className="main__header">
        <div className="about__naming">Home &gt; Donate</div>
        <h1 className="about__mainheading">Support Our Cause</h1>
        <p className="about__text">
          Join us in making a difference by donating to our cause. Your contribution can help change lives and build a better tomorrow.
        </p>
      </header>
    </div>
  )
}

export default Donate_header
