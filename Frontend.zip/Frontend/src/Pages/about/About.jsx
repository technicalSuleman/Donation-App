import React from 'react';
import './style.css';
import AboutHeader from '../../component/cause header/AboutHeader';
import AboutInfo from '../../component/about info/AboutInfo';
import Footer from '../../component/footer/Footer'
import Gallery from '../../component/gallery/Gallery'
import AboutOrgnization from '../../component/about info/AboutOrgnization';
import Volunteers from '../../component/volunteers/Volunteers';
import ProjectsByRegion from '../../component/ProjectsByRegion/ProjectsByRegion '; // Fixed: Removed trailing space

function About() {
  return (
    <>
      <AboutHeader />
      <AboutInfo />
      <AboutOrgnization />
      <Volunteers />
      <ProjectsByRegion />
      <Gallery />
      <Footer />
    </>
  );
}

export default About;
