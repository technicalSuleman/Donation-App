import React, { useState } from "react";
import { Card, Button, Row, Col, Pagination, Form, Modal } from "react-bootstrap";
import FavoriteIcon from "@mui/icons-material/Favorite";
import ShareIcon from "@mui/icons-material/Share";
import CommentIcon from "@mui/icons-material/Comment";
import DeleteIcon from "@mui/icons-material/Delete";
import Footer from "../../component/footer/Footer";
import BlogHeader from "../../component/blog/BlogHeader";

const Blog = () => {
  const [blogs, setBlogs] = useState([
    {
      id: 1,
      title: "The Importance of Giving Back",
      description: "Discover how small contributions can create a massive impact on communities in need.",
      image: "https://via.placeholder.com/400x200",
      date: "January 20, 2025",
      likes: 0,
      comments: [],
    },
    {
      id: 2,
      title: "Top 5 Charities to Support in 2025",
      description: "A curated list of trusted charities making waves in education, health, and the environment.",
      image: "https://via.placeholder.com/400x200",
      date: "February 5, 2025",
      likes: 0,
      comments: [],
    },
    {
      id: 3,
      title: "How Donations Change Lives",
      description: "Real stories of individuals and families transformed through your generosity.",
      image: "https://via.placeholder.com/400x200",
      date: "February 10, 2025",
      likes: 0,
      comments: [],
    },
  ]);

  const [search, setSearch] = useState("");
  const [currentPage, setCurrentPage] = useState(1);
  const itemsPerPage = 3;

  const [showCommentModal, setShowCommentModal] = useState(false);
  const [selectedBlog, setSelectedBlog] = useState(null);
  const [commentText, setCommentText] = useState("");

  // Like function
  const handleLike = (id) => {
    setBlogs((prevBlogs) =>
      prevBlogs.map((blog) =>
        blog.id === id ? { ...blog, likes: blog.likes + 1 } : blog
      )
    );
  };
 const openCommentModal = (blog) => {
    setSelectedBlog(blog);
    setShowCommentModal(true);
  };
  // Share function
  const handleShare = (blog) => {
    if (navigator.share) {
      navigator.share({
        title: blog.title,
        text: blog.description,
        url: window.location.href,
      });
    } else {
      alert("Sharing not supported on this browser.");
    }
  };

  // Open comment modal
 

  // Add comment
  const handleAddComment = () => {
    if (!commentText.trim()) return;
    setBlogs((prevBlogs) =>
      prevBlogs.map((blog) =>
        blog.id === selectedBlog.id
          ? { ...blog, comments: [...blog.comments, commentText] }
          : blog
      )
    );
    setCommentText("");
    setShowCommentModal(false);
  };

  // Delete comment
  const handleDeleteComment = (blogId, index) => {
    setBlogs((prevBlogs) =>
      prevBlogs.map((blog) =>
        blog.id === blogId
          ? {
              ...blog,
              comments: blog.comments.filter((_, i) => i !== index),
            }
          : blog
      )
    );
  };

  // Filter blogs
  const filteredBlogs = blogs.filter((blog) =>
    blog.title.toLowerCase().includes(search.toLowerCase())
  );

  // Pagination
  const indexOfLastItem = currentPage * itemsPerPage;
  const indexOfFirstItem = indexOfLastItem - itemsPerPage;
  const currentBlogs = filteredBlogs.slice(indexOfFirstItem, indexOfLastItem);
  const totalPages = Math.ceil(filteredBlogs.length / itemsPerPage);

  return (
    <>
      <BlogHeader />
      <div className="blog-section container py-5">
        <h2 className="text-center mb-4">Our Latest Blogs</h2>

        {/* Search Bar */}
        <Form className="mb-4">
          <Form.Control
            type="text"
            placeholder="Search blogs..."
            value={search}
            onChange={(e) => setSearch(e.target.value)}
          />
        </Form>

        <Row>
          {currentBlogs.map((blog) => (
            <Col key={blog.id} md={4} className="mb-4">
              <Card className="shadow-sm h-100">
                <Card.Img variant="top" src={blog.image} alt={blog.title} />
                <Card.Body>
                  <Card.Title>{blog.title}</Card.Title>
                  <Card.Text className="text-muted">{blog.date}</Card.Text>
                  <Card.Text>{blog.description}</Card.Text>
                  <div className="d-flex justify-content-between align-items-center">
                    <Button variant="outline-primary" className="btn-sm">
                      Read More
                    </Button>
                    <div className="icons d-flex gap-3">
                      {/* Like Button */}
                      <FavoriteIcon
                        style={{ color: "red", cursor: "pointer" }}
                        onClick={() => handleLike(blog.id)}
                      />
                      <span>{blog.likes}</span>

                      {/* Share Button */}
                      <ShareIcon
                        style={{ color: "blue", cursor: "pointer" }}
                        onClick={() => handleShare(blog)}
                      />

                      {/* Comment Button */}
                      <CommentIcon
                        style={{ color: "green", cursor: "pointer" }}
                        onClick={() => openCommentModal(blog)}
                      />
                    </div>
                  </div>

                  {/* Show comments */}
                  {blog.comments.length > 0 && (
                    <div className="mt-3">
                      <h6>Comments:</h6>
                      <ul className="list-unstyled">
                        {blog.comments.map((comment, index) => (
                          <li key={index} className="border-bottom py-1 d-flex justify-content-between align-items-center">
                            {comment}
                            <DeleteIcon
                              style={{ color: "red", cursor: "pointer" }}
                              onClick={() => handleDeleteComment(blog.id, index)}
                            />
                          </li>
                        ))}
                      </ul>
                    </div>
                  )}
                </Card.Body>
              </Card>
            </Col>
          ))}
        </Row>

        {/* Pagination */}
        <Pagination className="justify-content-center mt-4">
          {[...Array(totalPages)].map((_, index) => (
            <Pagination.Item
              key={index}
              active={index + 1 === currentPage}
              onClick={() => setCurrentPage(index + 1)}
            >
              {index + 1}
            </Pagination.Item>
          ))}
        </Pagination>
      </div>

      <Footer />

      {/* Comment Modal */}
      <Modal show={showCommentModal} onHide={() => setShowCommentModal(false)}>
        <Modal.Header closeButton>
          <Modal.Title>Add a Comment</Modal.Title>
        </Modal.Header>
        <Modal.Body>
          <Form.Control
            as="textarea"
            rows={3}
            placeholder="Write your comment..."
            value={commentText}
            onChange={(e) => setCommentText(e.target.value)}
          />
        </Modal.Body>
        <Modal.Footer>
          <Button variant="secondary" onClick={() => setShowCommentModal(false)}>
            Close
          </Button>
          <Button variant="primary" onClick={handleAddComment}>
            Post Comment
          </Button>
        </Modal.Footer>
      </Modal>
    </>
  );
};

export default Blog;
