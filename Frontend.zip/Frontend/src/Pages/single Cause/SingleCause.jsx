import React from 'react'
import './style.css'

function SingleCause() {
  return (
    <div>
      Single Cause
    </div>
  )
}

export default SingleCause
