import img1 from './assets/image/img_1.jpg'
import img2 from './assets/image/img_2.jpg'
import img3 from './assets/image/img_3.jpg'
export default [
    {
      src: img1,
      text: "Duis aute irure dolor in reprehenderit in voluptate velit esse",
    },
    {
      src: img2,
      text: "Consectetur adipisicing elit cillum dolore eu fugiat nulla",
    },
    {
      src: img3,
      text: "Asperiores ex animi explicabo cillum dolore eu fugiat nulla",
    },
  ]