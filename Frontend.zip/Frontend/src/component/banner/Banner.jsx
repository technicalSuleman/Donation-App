import React from "react";
import { useNavigate } from "react-router-dom"; // Import useNavigate for routing
import './style.css';

const Banner = () => {
  const navigate = useNavigate(); // Initialize useNavigate

  const handleNavigation = () => {
    navigate("/home"); // Navigate to the desired route, e.g., "/home"
  };

  return (
    <>
      <div className="banner__container">
        <div className="row">
          <div className="col-8 offset-2">
            <div className="text__container">
              <h2 className="main__heading">Transform Lives Today</h2>
              <h4 className="sub__heading">
                Your kindness can be the spark that changes someone's world.
              </h4>
              <p className="intro__text">
                A visually striking image of smiling children, families, or
                communities thriving because of donations.
              </p>
              <center>
                <button
                  className="btn btn-success explore__button"
                  onClick={handleNavigation}
                >
                  Explore More
                </button>
              </center>
            </div>
          </div>
        </div>
      </div>
    </>
  );
};

export default Banner;
