import React from 'react';

function Contect_heder() {
  return (
    <div>
      <div className='main__header'>
        <div className="row py-5">
          <div className="col-8 offset-2 text-center py-4">
            <span className='about__naming mt-5'>Home &gt; Contact</span>
            <h2 className='about__mainheading mb-3'>Every Act of Kindness Counts</h2>
            <p className='about__text'>
              A small act of kindness can create a big impact.  
              Whether you have a question, want to collaborate, or need assistance,  
              we are here to listen and support you.  
              Together, we can spread kindness and make the world a better place.  
              Reach out to us today—every connection matters!
            </p>
          </div>
        </div>
      </div>
    </div>
  );
}

export default Contect_heder;
