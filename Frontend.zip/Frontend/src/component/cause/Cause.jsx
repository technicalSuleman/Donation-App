import React from "react";
import { useNavigate } from "react-router-dom";
import "./style.css";
import feed_hungry from "../../assets/image/feed.jpg";
import education from "../../assets/image/education.jpg";
import relef from "../../assets/image/disaster_relef.jpg";
import madi_aid from "../../assets/image/first_aid.jpg";
import clean_water from "../../assets/image/clean_water.jpg";

function Cause() {
  const navigate = useNavigate();

  const causeList = [
    {
      id: 1,
      causeTitle: "Feed the Hungry",
      causeText: "Providing meals to families in need.",
      causeRaised: 6500,
      causeGoal: 15000,
      causeImg: feed_hungry,
      donations: 14,
    },
    {
      id: 2,
      causeTitle: "Educate a Child",
      causeText: "Supporting education for underprivileged children.",
      causeRaised: 12000,
      causeGoal: 25000,
      causeImg: education,
      donations: 20,
    },
    {
      id: 3,
      causeTitle: "Disaster Relief",
      causeText: "Helping communities recover from natural disasters.",
      causeRaised: 3000,
      causeGoal: 10000,
      causeImg: relef,
      donations: 10,
    },
    {
      id: 4,
      causeTitle: "Clean Water Initiative",
      causeText: "Providing access to clean and safe drinking water.",
      causeRaised: 9500,
      causeGoal: 20000,
      causeImg: clean_water,
      donations: 18,
    },
    {
      id: 5,
      causeTitle: "Medical Aid",
      causeText: "Providing medical supplies and treatment to those in need.",
      causeRaised: 20000,
      causeGoal: 40000,
      causeImg: madi_aid,
      donations: 25,
    },
  ];

  const handleViewDetails = (cause) => {
    navigate(`/donate/${cause.id}`, { state: cause });
  };

  return (
    <div className="container cause__container mb-5">
      <div className="row justify-content-between align-items-center mb-3">
        <div className="col-4">
          <h2 className="cause__heading">Latest Causes</h2>
        </div>
        <div className="col-4 text-md-end text-center">
          <button className="btn btn-outline-dark">More Causes</button>
        </div>
      </div>
      <div className="row">
        {causeList.map((cause) => (
          <div className="col-12 col-sm-6 col-md-4 mb-4" key={cause.id}>
            <div className="card h-100">
              <img
                src={cause.causeImg}
                className="card-img-top"
                alt={cause.causeTitle}
                style={{ height: 260, borderRadius: 5 }}
              />
              <div className="card-body d-flex flex-column">
                <h5 className="card-title">{cause.causeTitle}</h5>
                <p className="card-text">{cause.causeText}</p>
                <div className="d-flex justify-content-between align-items-center mt-auto">
                  <div>
                    <h6 className="donation__amount">Goal: ${cause.causeGoal}</h6>
                    <p className="donation__title">Raised: ${cause.causeRaised}</p>
                  </div>
                  <div>
                    <h6 className="donation__amount">{cause.donations}</h6>
                    <p className="donation__title">Donations</p>
                  </div>
                </div>
                <button 
                  className="btn btn-dark text-uppercase w-100 mt-3"
                  onClick={() => handleViewDetails(cause)}
                >
                  View Details
                </button>
              </div>
            </div>
          </div>
        ))}
      </div>
    </div>
  );
}

export default Cause;
