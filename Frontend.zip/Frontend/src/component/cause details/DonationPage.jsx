import React, { useState } from "react";
import { useLocation, useNavigate } from "react-router-dom";
import { Button } from "@mui/material";
import "./DonationPage.css";

const DonationPage = () => {
  const location = useLocation();
  const cause = location.state || {}; // Retrieve cause data
  const [donationAmount, setDonationAmount] = useState(0);
  const navigate = useNavigate();

  // Function to handle donation submission
  const handleDonate = () => {
    if (donationAmount > 0) {
      navigate("/donate", {
        state: {
          amount: donationAmount,
          causeName: cause.causeName || "Unknown Cause",
        },
      });
    }
  };

  return (
    <div className="donation-page container my-5">
      <div className="row">
        {/* Left Section */}
        <div className="col-md-8">
          <div className="donation-image mb-4">
            <img
              src={cause.causeImg || "https://via.placeholder.com/800x400"}
              alt="Cause"
              className="img-fluid rounded"
            />
          </div>
          <div className="progress mb-3" style={{ height: "10px" }}>
            <div
              className="progress-bar"
              role="progressbar"
              style={{ width: `${(cause.causeRaised / cause.causeGoal) * 100}%` }}
              aria-valuenow={cause.causeRaised}
              aria-valuemin="0"
              aria-valuemax={cause.causeGoal}
            ></div>
          </div>
          <div className="d-flex justify-content-between align-items-center mb-4">
            <h4>Goal: ${cause.causeGoal}</h4>
            <h4>Raised: ${cause.causeRaised}</h4>
            <h4>{cause.donations} Donations</h4>
          </div>

          {/* Donation Amount Section */}
          <div className="donation-amount mb-4">
            <h5 className="mb-3">Select Donation Amount</h5>
            <div className="btn-group" role="group">
              {[10, 25, 50, 100, 500].map((amount) => (
                <button
                  key={amount}
                  className={`btn btn-outline-dark ${donationAmount === amount ? "active" : ""}`}
                  onClick={() => setDonationAmount(amount)}
                >
                  ${amount}
                </button>
              ))}
            </div>
          </div>

          {/* Total and Submit */}
          <div className="d-flex justify-content-between align-items-center mt-4">
            <h4>Donation Total: ${donationAmount}</h4>
            <Button
              variant="contained"
              color="primary"
              size="large"
              onClick={handleDonate}
              disabled={!donationAmount}
            >
              Donate Now
            </Button>
          </div>
        </div>
      </div>
    </div>
  );
};

export default DonationPage;
