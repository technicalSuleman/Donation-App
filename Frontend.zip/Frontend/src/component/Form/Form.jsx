import React, { useState } from "react";
import {
  Box,
  Grid,
  Typography,
  Card,
  TextField,
  Button,
} from "@mui/material";
import CreditCardIcon from "@mui/icons-material/CreditCard";
import AccountBalanceWalletIcon from "@mui/icons-material/AccountBalanceWallet";
import PaymentIcon from "@mui/icons-material/Payment";
import { useLocation } from "react-router-dom";
import axios from "axios";

const Form = () => {
  const location = useLocation();
  const { causeName, amount } = location.state || {};

  const [cardNumber, setCardNumber] = useState("");
  const [expiryDate, setExpiryDate] = useState("");
  const [cvv, setCvv] = useState("");
  const [nameOnCard, setNameOnCard] = useState("");
  const [loading, setLoading] = useState(false);

  const handleExpiryDateChange = (e) => {
    let value = e.target.value.replace(/\D/g, ""); 
    if (value.length <= 4) {
      if (value.length > 2) {
        value = `${value.substring(0, 2)}/${value.substring(2)}`;
      }
      setExpiryDate(value);
    }
  };

  const handleCvvChange = (e) => {
    const value = e.target.value.replace(/\D/g, "").substring(0, 3);
    setCvv(value);
  };

  const handleSubmit = async (e) => {
    e.preventDefault();
    setLoading(true);

    const expMonth = expiryDate.split("/")[0];
    const expYear = expiryDate.split("/")[1];

    try {
      const response = await axios.post("http://localhost:5000/api/payments/pay", {
        amount,
        cardNumber: cardNumber.replace(/\s/g, ""),
        expMonth,
        expYear,
        cvv,
      });

      alert(response.data.message);
    } catch (error) {
      alert("Payment failed: " + error.response?.data?.message || error.message);
    }

    setLoading(false);
  };

  return (
    <Box sx={{ p: 4 }}>
      <Typography variant="h4" textAlign="center" gutterBottom>
        Donation Payment
      </Typography>

      <Grid container spacing={3} sx={{ mb: 4 }}>
        <Grid item xs={12} md={4}>
          <Card
            variant="outlined"
            sx={{ p: 2, textAlign: "center", "&:hover": { boxShadow: 4 } }}
          >
            <CreditCardIcon color="primary" sx={{ fontSize: 50 }} />
            <Typography mt={1}>**** **** **** 1060</Typography>
            <Typography variant="body2" color="textSecondary">
              Expiry: 10/26
            </Typography>
          </Card>
        </Grid>
        <Grid item xs={12} md={4}>
          <Card
            variant="outlined"
            sx={{ p: 2, textAlign: "center", "&:hover": { boxShadow: 4 } }}
          >
            <PaymentIcon color="secondary" sx={{ fontSize: 50 }} />
            <Typography mt={1}>**** **** **** 2045</Typography>
            <Typography variant="body2" color="textSecondary">
              Expiry: 07/27
            </Typography>
          </Card>
        </Grid>
        <Grid item xs={12} md={4}>
          <Card
            variant="outlined"
            sx={{ p: 2, textAlign: "center", "&:hover": { boxShadow: 4 } }}
          >
            <AccountBalanceWalletIcon color="success" sx={{ fontSize: 50 }} />
            <Typography mt={1}>Wallet Payment</Typography>
            <Typography variant="body2" color="textSecondary">
              Secure and Fast
            </Typography>
          </Card>
        </Grid>
      </Grid>

      <Box component="form" sx={{ maxWidth: "600px", mx: "auto" }} onSubmit={handleSubmit}>
        <Typography variant="h5" gutterBottom>
          Credit Card Payment
        </Typography>

        <TextField
          fullWidth
          label="Amount"
          value={amount}
          sx={{ mb: 3 }}
          InputProps={{ readOnly: true }}
        />
        <TextField
          fullWidth
          label="Card Number"
          placeholder="Enter your card number"
          value={cardNumber}
          onChange={(e) =>
            setCardNumber(e.target.value.replace(/\D/g, "").replace(/(\d{4})/g, "$1 ").trim())
          }
          inputProps={{ maxLength: 19 }}
          sx={{ mb: 3 }}
        />

        <Grid container spacing={2} sx={{ mb: 3 }}>
          <Grid item xs={12} md={6}>
            <TextField
              fullWidth
              label="Expiry Date (MM/YY)"
              placeholder="MM/YY"
              value={expiryDate}
              onChange={handleExpiryDateChange}
              inputProps={{ maxLength: 5 }}
            />
          </Grid>
          <Grid item xs={12} md={6}>
            <TextField
              fullWidth
              label="CVV"
              placeholder="CVV"
              value={cvv}
              onChange={handleCvvChange}
              inputProps={{ maxLength: 3 }}
              type="password"
            />
          </Grid>
        </Grid>

        <TextField
          fullWidth
          label="Name on the Card"
          placeholder="Cardholder name"
          value={nameOnCard}
          onChange={(e) => setNameOnCard(e.target.value)}
          sx={{ mb: 3 }}
        />

        <Button
          fullWidth
          type="submit"
          variant="contained"
          size="large"
          sx={{ py: 1.5 }}
          style={{ background: "#fd7e14" }}
          disabled={loading}
        >
          {loading ? "Processing..." : "Submit Payment"}
        </Button>
      </Box>
    </Box>
  );
};

export default Form;
