import React from 'react';
import './style.css';
import AutoStoriesIcon from '@mui/icons-material/AutoStories';
import WaterDropIcon from '@mui/icons-material/WaterDrop';
import LocalHospitalIcon from '@mui/icons-material/LocalHospital';
import FavoriteBorderIcon from '@mui/icons-material/FavoriteBorder';

function About() {
  const elements = [
    { num: 1, data: "Choose your cause" },
    { num: 2, data: "Donate the amount you like" },
    { num: 3, data: "Register on our website" },
    { num: 4, data: "Stay tuned about the cause" }
  ];

  const icon_text = [
    {
      icon: AutoStoriesIcon,
      heading: "Education",
      text: "Providing access to quality education for underprivileged children and adults to empower their future.",
    },
    {
      icon: WaterDropIcon,
      heading: "Clean Water",
      text: "Ensuring safe and clean drinking water to communities to promote better health and hygiene.",
    },
    {
      icon: LocalHospitalIcon,
      heading: "Health Care",
      text: "Delivering essential healthcare services and promoting awareness for a healthier society.",
    },
    {
      icon: FavoriteBorderIcon,
      heading: "Local Communities",
      text: "Supporting and uplifting local communities through various development programs and initiatives.",
    },
  ];
  

  return (
    <div className="main__about ">
      <div className="container">
        <div className="row align-items-center">
          {/* Left Column: Image Container */}
          <div className="col-12 col-md-6">
            <div className="image__container">
              
            </div>
          </div>

          {/* Right Column: Content */}
          <div className="col-12 col-md-6 ">
            <h1 className="about__header">Transforming Good Intentions into Good Actions</h1>
            <p className="about__text">
              Good intentions are the seeds of positive change, but without action, they remain dormant ideas.
              The true power of kindness lies in turning these intentions into meaningful deeds that impact lives
              and create ripples of hope.
            </p>

            {/* Steps Section */}
            <div className="d-flex justify-content-between flex-wrap">
              {elements.map((step) => (
                <div
                  key={step.num}
                  className="d-flex align-items-center mb-4 mx-1 mt-4"
                  style={{ maxWidth: "400px" }}
                >
    
                  <div
                    className="rounded-circle bg-warning text-white d-flex justify-content-center align-items-center me-2"
                    style={{
                      width: "30px",
                      height: "30px",
                      fontWeight: "bold",
                    }}
                  >
                    {step.num}
                  </div>
                  {/* Step Text */}
                  <span style={{fontSize: 20, color: "#000000"}}>{step.data}</span>
                </div>
              ))}
            </div>
          </div>
        </div>
        <section className="icon__section mt-5 mb-5">
  <div className="row">
    {icon_text.map((item, id) => (
      <div className="col-12 col-md-3 text-center mb-4" key={id}>
        {/* Icon Section */}
        <div>
          <item.icon style={{ fontSize: "3rem", color: "#FD7E14" }} /> {/* Display the icon */}
        </div>
        {/* Text Section */}
        <div>
          <h5 className="mt-2">{item.heading}</h5> {/* Render the heading */}
          <p>{item.text}</p> {/* Render the text */}
        </div>
      </div>
    ))}
  </div>
</section>
      </div>
    </div>
  );
}

export default About;
