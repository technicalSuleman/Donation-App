import React, { useEffect, useState } from "react";
import "./style.css";
import CheckCircleIcon from "@mui/icons-material/CheckCircle";
import VolunteerActivismIcon from "@mui/icons-material/VolunteerActivism";
import GroupWorkIcon from "@mui/icons-material/GroupWork";
import AttachMoneyIcon from "@mui/icons-material/AttachMoney";

function AboutInfo() {
  const info = [
    {
      icon: <CheckCircleIcon sx={{ fontSize: 50, color: "#FD7E14" }} />,
      amount: 1200,
      title: "Projects Completed",
    },
    {
      icon: <VolunteerActivismIcon sx={{ fontSize: 50, color: "#FD7E14" }} />,
      amount: 100,
      title: "Monthly Donors",
    },
    {
      icon: <GroupWorkIcon sx={{ fontSize: 50, color: "#FD7E14" }} />,
      amount: 480,
      title: "Partners Worldwide",
    },
    {
      icon: <AttachMoneyIcon sx={{ fontSize: 50, color: "#FD7E14" }} />,
      amount: 1400000,
      title: "Donations Received",
    },
  ];

  const [counts, setCounts] = useState(info.map(() => 0));

  useEffect(() => {
    const duration = 2000;
    const frames = 120;
    const intervalDuration = duration / frames;
    const increments = info.map((item) => item.amount / frames);

    const interval = setInterval(() => {
      setCounts((prevCounts) =>
        prevCounts.map((count, index) => {
          const nextValue = count + increments[index];
          return nextValue >= info[index].amount ? info[index].amount : nextValue;
        })
      );

      const allComplete = counts.every((value, index) => value >= info[index].amount);
      if (allComplete) clearInterval(interval);
    }, intervalDuration);

    return () => clearInterval(interval);
  }, [info]);

  return (
    <div className="container py-5 info__container">
      <div className="row text-center">
        {info.map((item, index) => (
          <div className="col-12 col-md-3 mb-4" key={index}>
            <div className="info-card">
              <div className="info__icon">{item.icon}</div>
              <h3 className="info__amount">{Math.floor(counts[index]).toLocaleString()}</h3>
              <p className="info__title">{item.title}</p>
            </div>
          </div>
        ))}
      </div>
    </div>
  );
}

export default AboutInfo;
