import React, { useEffect, useState } from "react";
import "./style.css";
import FavoriteIcon from "@mui/icons-material/Favorite";
import VisibilityIcon from "@mui/icons-material/Visibility";
import EmojiEventsIcon from "@mui/icons-material/EmojiEvents";

function AboutOrganization() {
  const [dynamicText, setDynamicText] = useState({
    mission: "Loading mission...",
    vision: "Loading vision...",
    values: "Loading values...",
  });

  useEffect(() => {
    const missionText =
      "Our mission is to empower communities by providing access to education, health, and financial support.";
    const visionText =
      "We envision a world where every individual has the opportunity to thrive and contribute to a better future.";
    const valuesText =
      "Our core values include compassion, integrity, collaboration, and accountability.";

    const timers = [
      setTimeout(() => setDynamicText((prev) => ({ ...prev, mission: missionText })), 1000),
      setTimeout(() => setDynamicText((prev) => ({ ...prev, vision: visionText })), 2000),
      setTimeout(() => setDynamicText((prev) => ({ ...prev, values: valuesText })), 3000),
    ];

    return () => timers.forEach((timer) => clearTimeout(timer)); // Cleanup on component unmount
  }, []);

  return (
    <div className="container organization__container py-5 mt-5">
      <div className="row align-items-center">
        
        <div className="col-12 col-lg-6 mb-4 mb-lg-0">
          <h2 className="organization__heading mb-4">About our Organization</h2>
          <div className="organization__content">
            
            <div className="organization__item mb-4 d-flex align-items-start">
              <div className="organization__icon-circle">
                <FavoriteIcon className="organization__icon" />
              </div>
              <div>
                <h4 className="organization__title">Our Mission</h4>
                <p className="organization__text">{dynamicText.mission}</p>
              </div>
            </div>
            
            <div className="organization__item mb-4 d-flex align-items-start">
              <div className="organization__icon-circle">
                <VisibilityIcon className="organization__icon" />
              </div>
              <div>
                <h4 className="organization__title">Our Vision</h4>
                <p className="organization__text">{dynamicText.vision}</p>
              </div>
            </div>
            
            <div className="organization__item d-flex align-items-start">
              <div className="organization__icon-circle">
                <EmojiEventsIcon className="organization__icon" />
              </div>
              <div>
                <h4 className="organization__title">Our Values</h4>
                <p className="organization__text">{dynamicText.values}</p>
              </div>
            </div>
          </div>
        </div>

        {/* Right Side: Images */}
        <div className="col-12 col-lg-6 d-flex justify-content-center">
          <div className="organization__images d-flex flex-column flex-lg-row gap-3">
            <div className="image-card image-card-1"></div>
            <div className="image-card image-card-2"></div>
          </div>
        </div>
      </div>
    </div>
  );
}

export default AboutOrganization;
