import React from 'react'

function BlogHeader() {
  return (
    <div>
      <div className="main__header">
        <div className="row py-5">
          <div className="col-10 offset-1 text-center py-4">
            <span className="about__naming mt-5">Home &gt; Blog</span>
            <h2 className="about__mainheading mb-3">Inspiring Stories, Meaningful Impact</h2>
            <p className="about__text">
              Explore heartfelt stories of generosity, impact, and change. Our blog highlights the power of donations,  
              shares updates on charitable initiatives, and celebrates the kindness that transforms lives.  
              Stay informed, get inspired, and join us in making a difference—one story at a time.
            </p>
          </div>
        </div>
      </div>
    </div>
  )
}

export default BlogHeader;
