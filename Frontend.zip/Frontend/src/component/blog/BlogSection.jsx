import React from "react";
import "bootstrap/dist/css/bootstrap.min.css";
import "./BlogSection.css";
import where from '../../assets/image/where.jpg'
import papuler from '../../assets/image/public charter.jpg'
import child from '../../assets/image/child (2).jpg'

const BlogSection = () => {
  const blogs = [
    {
      date: "June 20, 2024",
      title: "Where to Give Now",
      description:
        "Explore impactful ways to give to those in need and make a difference in their lives.",
      image:where, 
      link: "#",
    },
    {
      date: "June 22, 2024",
      title: "Popular Charities",
      description:
        "Learn about the top charities doing incredible work in the community and beyond.",
      image: papuler,
      link: "#",
    },
    {
      date: "June 24, 2024",
      title: "Childcare Crisis",
      description:
        "Understand the growing childcare crisis and how your contributions can help.",
      image: child,
      link: "#",
    },
  ];

  return (
    <div className="container py-5 blog-section">
      <div className="d-flex justify-content-between align-items-center mb-4">
        <h2 className="fw-bold blog-heading">Latest News and Blog</h2>
        <button className="btn btn-outline-dark fw-bold more-news-btn">
          More News
        </button>
      </div>
      <div className="row">
        {blogs.map((blog, index) => (
          <div className="col-md-4 mb-4" key={index}>
            <div className="card blog-card h-100 border-0 shadow">
              <img
                src={blog.image}
                alt={blog.title}
                className="card-img-top rounded-top blog-image"
                height={250}
              />
              <div className="card-body">
                <p className="text-muted mb-2 blog-date">{blog.date}</p>
                <h5 className="card-title fw-bold blog-title">{blog.title}</h5>
                <p className="card-text blog-description text-muted">
                  {blog.description.substring(0, 80)}...
                </p>
                <a
                  href={blog.link}
                  className="text-decoration-none  fw-bold read-more-link"
                  style={{color :"#fd7e14"}}
                >
                  Read More <span className="ms-1">→</span>
                </a>
              </div>
            </div>
          </div>
        ))}
      </div>
    </div>
  );
};

export default BlogSection;
