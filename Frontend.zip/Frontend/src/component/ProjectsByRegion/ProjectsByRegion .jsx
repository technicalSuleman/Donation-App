import React, { useState } from "react";
import Map, { Marker, Popup } from "react-map-gl";
import "mapbox-gl/dist/mapbox-gl.css";

const mapboxToken = "pk.eyJ1Ijoic2tjb2RlciIsImEiOiJjbTN2eXhmcW0wd3R5MnJxemFsdm1paXowIn0.77L7hpMyk6e9owjsl19YGw";

const mapContainerStyle = {
  width: "100%",
  height: "500px",
};

const regions = {
  "Central Africa": [
    { lat: -1.5, lng: 19.0 },
    { lat: 1.5, lng: 22.0 },
  ],
  "Eastern Europe": [
    { lat: 48.0, lng: 37.0 },
    { lat: 50.0, lng: 30.0 },
  ],
  "Southeast Asia": [
    { lat: 10.0, lng: 104.0 },
    { lat: 15.0, lng: 100.0 },
  ],
  "Central America": [
    { lat: 10.0, lng: -85.0 },
    { lat: 15.0, lng: -90.0 },
  ],
};

const ProjectsByRegion = () => {
  const [selectedRegion, setSelectedRegion] = useState("Central Africa");
  const [selectedMarker, setSelectedMarker] = useState(null);

  return (
    <div className="container text-center py-5">
      <h2 className="fw-bold">Projects by Region</h2>
      <p className="text-muted">
        Adipiscing in vitae nec posuere eget fringilla a morbi. Ultricies lacus
        turpis proin tempor faucibus ullamcorper massa tristique est...
      </p>

      <div className="d-flex justify-content-center mb-4">
        <ul className="nav nav-tabs">
          {Object.keys(regions).map((region) => (
            <li className="nav-item" key={region}>
              <button
                className={`nav-link ${
                  selectedRegion === region
                    ? "active text-warning fw-bold"
                    : "text-dark"
                }`}
                onClick={() => setSelectedRegion(region)}
              >
                {region}
              </button>
            </li>
          ))}
        </ul>
      </div>

      <Map
        mapboxAccessToken={mapboxToken}
        initialViewState={{
          longitude: regions[selectedRegion][0].lng,
          latitude: regions[selectedRegion][0].lat,
          zoom: 4,
        }}
        style={mapContainerStyle}
        mapStyle="mapbox://styles/mapbox/streets-v11"
      >
        {regions[selectedRegion].map((marker, index) => (
          <Marker
            key={index}
            longitude={marker.lng}
            latitude={marker.lat}
            onClick={() => setSelectedMarker(marker)}
          >
            <div
              style={{
                backgroundColor: "red",
                borderRadius: "50%",
                width: "10px",
                height: "10px",
              }}
            ></div>
          </Marker>
        ))}

        {selectedMarker && (
          <Popup
            longitude={selectedMarker.lng}
            latitude={selectedMarker.lat}
            closeOnClick={false}
            onClose={() => setSelectedMarker(null)}
          >
            <div>
              <p><strong>Marker Details:</strong></p>
              <p>Latitude: {selectedMarker.lat}</p>
              <p>Longitude: {selectedMarker.lng}</p>
            </div>
          </Popup>
        )}
      </Map>
    </div>
  );
};

export default ProjectsByRegion;
