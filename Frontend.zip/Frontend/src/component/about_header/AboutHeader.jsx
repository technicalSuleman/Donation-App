import React from 'react';
import './style.css';
import AutoStoriesIcon from '@mui/icons-material/AutoStories';
import WaterDropIcon from '@mui/icons-material/WaterDrop';
import LocalHospitalIcon from '@mui/icons-material/LocalHospital';
import FavoriteBorderIcon from '@mui/icons-material/FavoriteBorder';
import Cause from '../cause/Cause';

function AboutHeader() {
    const icon_text = [
        {
          icon: AutoStoriesIcon,
          heading: "Education",
          text: "Providing access to quality education for underprivileged children and adults to empower their future.",
        },
        {
          icon: WaterDropIcon,
          heading: "Clean Water",
          text: "Ensuring safe and clean drinking water to communities to promote better health and hygiene.",
        },
        {
          icon: LocalHospitalIcon,
          heading: "Health Care",
          text: "Delivering essential healthcare services and promoting awareness for a healthier society.",
        },
        {
          icon: FavoriteBorderIcon,
          heading: "Local Communities",
          text: "Supporting and uplifting local communities through various development programs and initiatives.",
        },
      ];
  return (
    <div className='main__header'>
      <div className="row py-5">
        <div className="col-8 offset-2 text-center py-4">
          <span className='about__naming mt-5'>Home &gt; Cause</span>
          <h2 className='about__mainheading mb-3'>Donate Today: Save a Life</h2>
          <p className='about__text'>
            Your contribution can make a real difference in someone's life. 
            Join us in our mission to provide aid and hope to those in need. 
            Every donation brings us closer to building a brighter future for those less fortunate. 
            Together, we can change lives and make the world a better place.
          </p>
        </div>
      </div>
    </div>
  );
}

export default AboutHeader;
