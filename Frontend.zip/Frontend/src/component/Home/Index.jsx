import React, { useState } from "react";
import { Link } from "react-router-dom"; // Import Link for navigation
import "./style.css";
import About from '../about/About'
import Cause from "../cause/Cause";
import Gallery from "../gallery/Gallery";
import QuoteSection from "../qoute/QuoteSection";
import BlogSection from "../blog/BlogSection";
import Footer from "../footer/Footer";
import ProjectsByRegion from "../ProjectsByRegion/ProjectsByRegion ";

function Index() {
  

  return (
    <>
      <div className="main__container">
        <div className="container" >
          <div className="row">
            <div className="col-6">
              <h1 className="hero__header">Give hope, save lives</h1>
              <p className="hero__text">
                Welcome to DONIFY – a place where compassion meets action. We
                connect generous hearts like yours with causes that change
                lives. Together, we can fight hunger, provide education, save
                lives, and bring hope to millions.
              </p>
            </div>
          </div>
          <div className="row">
            <div className="col-3">
              <span>
                <h2 className="amount__donate">RS. 343535</h2>
                <p className="sm-title text-center">Donation</p>
              </span>
            </div>
            <div className="col-3">
              <span>
                <h2 className="amount__donate">343535</h2>
                <p className="sm-title text-center">People Helped</p>
              </span>
            </div>
          </div>
        </div>
      </div>
      <About />
      <div className="gap"></div>
      <Cause />
      <Gallery />
      <QuoteSection />
      <BlogSection />
      <ProjectsByRegion />
      <Footer />
    </>
  );
}

export default Index;
