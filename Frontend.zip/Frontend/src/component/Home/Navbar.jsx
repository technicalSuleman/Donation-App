import React, { useState } from "react";
import { Link, useNavigate } from "react-router-dom";
import "./style.css";

function Navbar() {
  const [active, setActive] = useState("home");
  const [menuOpen, setMenuOpen] = useState(false);
  const navigate = useNavigate();

  const handleSetActive = (section) => {
    setActive(section);
    setMenuOpen(false);
  };

  const handleDonate = () => {
    setActive("donate");
    navigate("/donate");
  };

  return (
    <div>
      <div className="row">
        <div className="col-12">
          <nav className="navbar navbar-expand-lg main__nav">
            <div className="container-fluid">
              <div className="brand__info">
                <Link className="navbar-brand" to="/" onClick={() => handleSetActive("home")}>
                  Donify
                </Link>
              </div>
              <div className="gap__navbar"></div>
              <button
                className="navbar-toggler mx-4 mt-2"
                type="button"
                onClick={() => setMenuOpen(!menuOpen)}
                aria-expanded={menuOpen}
                aria-label="Toggle navigation"
              >
                <span className="navbar-toggler-icon"></span>
              </button>
              <div
                className={`collapse navbar-collapse ${menuOpen ? "show" : ""}`}
                id="navbarSupportedContent"
              >
                <ul className="navbar-nav me-auto mb-2 mb-lg-0">
                  <li className="nav-item">
                    <Link
                      className={`nav-link ${active === "home" ? "active" : ""} text-light`}
                      to="/home"
                      onClick={() => handleSetActive("home")}
                    >
                      Home
                    </Link>
                  </li>
                  <li className="nav-item">
                    <Link
                      className={`nav-link ${active === "cause" ? "active" : ""} text-light`}
                      to="/cause"
                      onClick={() => handleSetActive("cause")}
                    >
                      Cause
                    </Link>
                  </li>
                  <li className="nav-item">
                    <Link
                      className={`nav-link ${active === "Blog" ? "active" : ""} text-light`}
                      to="/blog"
                      onClick={() => handleSetActive("Blog")}
                    >
                      blog
                    </Link>
                  </li>
                  <li className="nav-item">
                    <Link
                      className={`nav-link ${active === "about" ? "active" : ""} text-light`}
                      to="/about"
                      onClick={() => handleSetActive("about")}
                    >
                      About
                    </Link>
                  </li>
                  <li className="nav-item">
                    <Link
                      className={`nav-link ${active === "contact" ? "active" : ""} text-light`}
                      to="/contact"
                      onClick={() => handleSetActive("contact")}
                    >
                      Contact
                    </Link>
                  </li>
                </ul>
              </div>
              <button
                className={`donate__button ${active === "donate" ? "active" : ""}`}
                onClick={handleDonate}
              >
                Donate
              </button>
            </div>
          </nav>
        </div>
      </div>
    </div>
  );
}

export default Navbar;
