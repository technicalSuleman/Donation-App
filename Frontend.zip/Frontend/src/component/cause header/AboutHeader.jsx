import React from 'react';
import './style.css';

function AboutHeader() {
  return (
    <div className="main__header">
      <div className="row py-5">
        <div className="col-10 offset-1 text-center py-4">
          <span className="about__naming mt-5">Home &gt; About Us</span>
          <h2 className="about__mainheading mb-3">United for Good, Strong for Charity</h2>
          <p className="about__text">
            United in purpose, we stand strong for those in need. Our mission is to bring hope, support, 
            and lasting change to communities around the world. Together, we strive to make a meaningful impact, 
            one act of kindness at a time. Your generosity fuels our vision of a brighter, more compassionate future 
            for everyone. Join us, and let’s create change, inspire hope, and build a better tomorrow.
          </p>
        </div>
      </div>
    </div>
  );
}

export default AboutHeader;
