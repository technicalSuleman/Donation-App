import React, { useState } from "react";
import { TextField, Button } from "@mui/material";
import { Phone, Email, LocationOn, AccessTime } from "@mui/icons-material";
import "./style.css";

function ContactUsForm() {
  const [first, setFirst] = useState("");
  const [last, setLast] = useState("");
  const [email, setEmail] = useState("");
  const [phone, setPhone] = useState("");
  const [subject, setSubject] = useState("");
  const [message, setMessage] = useState("");
  const [successMessage, setSuccessMessage] = useState("");
  const [errorMessage, setErrorMessage] = useState("");
  const name = first + " " + last;

  const handleSubmit = async (e) => {
    e.preventDefault();

    const formData = { name, email, phone, subject, message };

    try {
      const response = await fetch("http://localhost:5000/api/contact/submit", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify(formData),
      });

      const data = await response.json();
      if (response.ok) {
        setSuccessMessage("Message sent successfully! ✅");
        setErrorMessage(""); // Clear any previous errors
        // Clear form fields after success
        setFirst("");
        setLast("");
        setEmail("");
        setPhone("");
        setSubject("");
        setMessage("");
      } else {
        setErrorMessage("Error: " + data.error);
        setSuccessMessage(""); // Clear success message
      }
    } catch (error) {
      console.error("Error submitting form:", error);
      setErrorMessage("Server error. Try again later.");
      setSuccessMessage(""); // Clear success message
    }
  };

  return (
    <div className="container py-5">
      <div className="row">
        {/* Left Section */}
        <div className="col-md-4 left__part p-4">
          <h3 className="mb-4 heading__form">Share love, donate hope.</h3>
          <p className="mb-4 sub__text">
            Ut ac mattis senectus ac suspendisse vitae vel nulla eleifend. Est eros facilisi aenean nulla diam amet.
          </p>
          <p className="mb-3 text-white">
            <LocationOn className="me-2 form__icon" /> Balqees Adhi home township, <br />
            <span className="mx-4">Lahore</span>
          </p>
          <p className="mb-3 text-white">
            <Phone className="me-2 form__icon" /> +93275442657
          </p>
          <p className="mb-3 text-white">
            <Email className="me-2 form__icon" /> charity@email.net
          </p>
          <p className="text-white">
            <AccessTime className="me-2 form__icon" /> Mon-Fri: 8:00am - 6:00pm
          </p>
          <div className="d-flex mt-4">
            <a href="#" className="text-light me-3"><i className="fab fa-facebook fa-lg"></i></a>
            <a href="#" className="text-light me-3"><i className="fab fa-twitter fa-lg"></i></a>
            <a href="#" className="text-light"><i className="fab fa-instagram fa-lg"></i></a>
          </div>
        </div>

        {/* Right Section */}
        <div className="col-md-8 p-4">
          {/* Error / Success Messages */}
          {errorMessage && <div className="alert alert-danger">{errorMessage}</div>}
          {successMessage && <div className="alert alert-success">{successMessage}</div>}

          <form onSubmit={handleSubmit}>
            <div className="row">
              <div className="col-md-6 mb-4">
                <TextField fullWidth label="First Name" variant="outlined" value={first} onChange={(e) => setFirst(e.target.value)} />
              </div>
              <div className="col-md-6 mb-4">
                <TextField fullWidth label="Last Name" variant="outlined" value={last} onChange={(e) => setLast(e.target.value)} />
              </div>
              <div className="col-md-6 mb-4">
                <TextField fullWidth label="Email Address" variant="outlined" value={email} onChange={(e) => setEmail(e.target.value)} />
              </div>
              <div className="col-md-6 mb-4">
                <TextField fullWidth label="Phone Number" variant="outlined" value={phone} onChange={(e) => setPhone(e.target.value)} />
              </div>
              <div className="col-12 mb-4">
                <TextField fullWidth label="Subject" variant="outlined" value={subject} onChange={(e) => setSubject(e.target.value)} />
              </div>
              <div className="col-12 mb-4">
                <TextField
                  fullWidth
                  label="Message"
                  variant="outlined"
                  multiline
                  rows={4}
                  value={message}
                  onChange={(e) => setMessage(e.target.value)}
                />
              </div>
              <div className="col-12 mt-4">
                <Button
                  type="submit"
                  className="send__button"
                  fullWidth
                  variant="contained"
                  style={{ backgroundColor: "#FD7E14" }}
                  size="large"
                >
                  SEND MESSAGE
                </Button>
              </div>
            </div>
          </form>
        </div>
      </div>
    </div>
  );
}

export default ContactUsForm;
