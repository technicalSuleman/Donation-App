import React from 'react'
import './style.css'

function Contect_Hero() {
  return (
    <div className='container mb-2'>
      <div className="row">
        <div className="col-12 heroo_container">
          
        </div>
      </div>
    </div>
  )
}

export default Contect_Hero
