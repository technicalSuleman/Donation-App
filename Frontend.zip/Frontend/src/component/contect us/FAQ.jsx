import React, { useState } from "react";
import { Accordion, AccordionSummary, AccordionDetails } from "@mui/material";
import ExpandMoreIcon from "@mui/icons-material/ExpandMore";
import CloseIcon from "@mui/icons-material/Close";
import "bootstrap-icons/font/bootstrap-icons.css";

const FAQ = () => {
  const [expanded, setExpanded] = useState(false);

  const handleChange = (panel) => (event, isExpanded) => {
    setExpanded(isExpanded ? panel : false);
  };

  return (
    <div className="p-5 d-flex justify-content-between">
      <div style={{ flex: 1 }}>
        <h1 className="fw-bold mb-3">Frequently Asked Questions</h1>
        <p className="text-muted">Our FAQ section is designed to address the most common queries about our donation process, ensuring you have all the information you need to make informed contributions.</p>
      </div>

      <div style={{ flex: 2 }}>
        <Accordion
          expanded={expanded === "panel1"}
          onChange={handleChange("panel1")}
          className="mb-3 shadow-sm"
        >
          <AccordionSummary
            expandIcon={<ExpandMoreIcon />}
            aria-controls="panel1-content"
            id="panel1-header"
          >
            <h5 className="fw-semibold">What charities can I give to?</h5>
          </AccordionSummary>
          <AccordionDetails className="d-flex justify-content-between">
            <p className="text-secondary">
              You can give to a variety of charities that focus on education, health, disaster relief,
              environmental conservation, and community development. We partner with trusted
              organizations to ensure your contributions make a meaningful impact.
            </p>
            <CloseIcon style={{ cursor: "pointer", color: "red" }} onClick={() => setExpanded(false)} />
          </AccordionDetails>
        </Accordion>

        {[{
          question: "Is there a minimum/maximum amount I can donate?",
          answer: "Yes, the minimum amount is $10, and there is no maximum limit. However, certain campaigns may have their own specific limits."
        }, {
          question: "Can I give to more than one charity?",
          answer: "Absolutely! You can support multiple charities by selecting them during the donation process."
        }, {
          question: "When will my charity receive my donation?",
          answer: "Donations are processed immediately and are typically transferred to the chosen charity within 3-5 business days."
        }, {
          question: "Will my chosen charity receive all my donation?",
          answer: "Yes, the charity receives the full amount of your donation. However, a small transaction fee may apply, which will be displayed during the checkout process."
        }].map((item, index) => (
          <Accordion
            key={index}
            expanded={expanded === `panel${index + 2}`}
            onChange={handleChange(`panel${index + 2}`)}
            className="mb-3 shadow-sm"
          >
            <AccordionSummary
              expandIcon={<ExpandMoreIcon />}
              aria-controls={`panel${index + 2}-content`}
              id={`panel${index + 2}-header`}
            >
              <h5 className="fw-semibold">{item.question}</h5>
            </AccordionSummary>
            <AccordionDetails>
              <p className="text-secondary">{item.answer}</p>
            </AccordionDetails>
          </Accordion>
        ))}
      </div>
    </div>
  );
};

export default FAQ;
