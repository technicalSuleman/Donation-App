import React from "react";
import { Carousel } from "react-bootstrap";
import FacebookIcon from "@mui/icons-material/Facebook";
import TwitterIcon from "@mui/icons-material/Twitter";
import InstagramIcon from "@mui/icons-material/Instagram";
import img1 from "../../assets/image/suleman.jpg";
import img2 from "../../assets/image/awais.jpg";
import img3 from "../../assets/image/waqas.jpg";
import img4 from "../../assets/image/muzi.jpg";
import img5 from "../../assets/image/samar.jpg";
import img6 from "../../assets/image/s1.jpeg";

import "./Volunteers.css";

function Volunteers() {
  const volunteers = [
    { name: "Suleman Khan", role: "Volunteer", image: img1 },
    { name: "M. Awais", role: "Volunteer", image: img2 },
    { name: "Waqas", role: "Volunteer", image: img3 },
    { name: "Muzammil Irfan", role: "Volunteer", image: img4 },
    { name: "Samar Ahmad", role: "Volunteer", image: img5 },
    { name: "SK Coder", role: "Volunteer", image: img6 },
  ];

  // Group volunteers into chunks of 3
  const chunkedVolunteers = [];
  for (let i = 0; i < volunteers.length; i += 3) {
    chunkedVolunteers.push(volunteers.slice(i, i + 3));
  }

  return (
    <div className="volunteers-section text-center">
      <h2 className="header__volunter">Our Volunteers</h2>
      <Carousel indicators interval={null} controls={false} className="volunteers-slider">
        {chunkedVolunteers.map((group, index) => (
          <Carousel.Item key={index}>
            <div className="row justify-content-center">
              {group.map((volunteer, idx) => (
                <div className="col-12 col-md-4 mb-4" key={idx}>
                  <div className="volunteer-card">
                    {/* Volunteer Image */}
                    <div className="volunteer-image">
                      <img
                        src={volunteer.image}
                        alt={volunteer.name}
                        className="img-fluid w-100 h-100"
                        style={{ borderRadius: "10px", objectFit: "contain" }}
                      />
                    </div>
                    {/* Volunteer Details */}
                    <h5>{volunteer.name}</h5>
                    <p>{volunteer.role}</p>
                    {/* Social Media Icons */}
                    <div className="social-icons d-flex justify-content-center gap-3">
                      <a href="#" className="text-dark">
                        <FacebookIcon />
                      </a>
                      <a href="#" className="text-dark">
                        <TwitterIcon />
                      </a>
                      <a href="#" className="text-dark">
                        <InstagramIcon />
                      </a>
                    </div>
                  </div>
                </div>
              ))}
            </div>
          </Carousel.Item>
        ))}
      </Carousel>
    </div>
  );
}

export default Volunteers;
