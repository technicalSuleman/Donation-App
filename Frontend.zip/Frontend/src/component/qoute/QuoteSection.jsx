import React, { useState, useRef } from "react";
import "bootstrap/dist/css/bootstrap.min.css";
import "./QuoteSection.css";
import donate_video from "../../assets/image/donate.mp4";

const QuoteSection = () => {
  const [currentSlide, setCurrentSlide] = useState(0);
  const [isPlaying, setIsPlaying] = useState(false);
  const videoRef = useRef(null);

  const slides = [
    {
      quote: "Together, we can change lives for the better.",
      description:
        "Your small contributions can bring about significant changes in the lives of those in need. Let’s join hands to create a brighter future.",
      author: "George Henry",
      role: "Generous Donor",
    },
    {
      quote: "Every act of kindness matters.",
      description:
        "Even the smallest efforts, when multiplied by millions of people, can transform the world. Start today and be the difference.",
      author: "Jane Doe",
      role: "Dedicated Volunteer",
    },
    {
      quote: "Be the change you wish to see in the world.",
      description:
        "By taking action, you inspire others to follow your lead. Together, we can make impactful strides toward equality and support.",
      author: "John Smith",
      role: "Passionate Activist",
    },
  ];

  const toggleVideoPlayback = () => {
    if (isPlaying) {
      videoRef.current.pause();
    } else {
      videoRef.current.play();
    }
    setIsPlaying(!isPlaying);
  };

  return (
    <div className="container main__qoutContainer py-5">
      <div className="row align-items-center">
        {/* Quote Section */}
        <div className="col-md-6 mb-3" height ="350px">
          <div className="mb-3" style={{ height: "450px" }}>
            <h1 className="comma ">❝</h1>
            <h2 className="fw-bold mb-4 qoute__header">{slides[currentSlide].quote}</h2>
            <p className="text-muted">{slides[currentSlide].description}</p>
            <p className="fw-bold mt-4 mb-0">{slides[currentSlide].author}</p>
            <p className="text-muted">{slides[currentSlide].role}</p>
          </div>
          <div className="d-flex justify-content-center mt-4">
            {slides.map((_, index) => (
              <span
                key={index}
                className={`dot mx-1 ${index === currentSlide ? "warning" : "secondary"}`}
                style={{
                  width: "12px",
                  height: "12px",
                  borderRadius: "50%",
                  cursor: "pointer",
                }}
                onClick={() => setCurrentSlide(index)}
              ></span>
            ))}
          </div>
        </div>

        {/* Video Section */}
        <div className="col-md-6">
          <div
            className="position-relative bg-dark"
            style={{
              height: "100%",
              borderRadius: "20px",
              overflow: "hidden",
              maxHeight: "450px",
            }}
          >
            <video
              ref={videoRef}
              src={donate_video}
              className="img-fluid"
              style={{
                height: "100%",
                width: "100%",
                objectFit: "cover",
                borderRadius: "20px",
              }}
              muted
              autoPlay
              loop
            ></video>
            <button
              className="btn btn-warning position-absolute top-50 start-50 translate-middle rounded-circle"
              style={{ width: "60px", height: "60px", color: "#fd7e14" }}
              onClick={toggleVideoPlayback}
            >
              <i
                className={`bi ${isPlaying ? "bi-pause-fill" : "bi-play-fill"} text-white`}
                style={{ fontSize: "1.5rem" }}
              ></i>
            </button>
          </div>
        </div>
      </div>
    </div>
  );
};

export default QuoteSection;
