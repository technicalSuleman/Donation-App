import React from "react";
import "bootstrap/dist/css/bootstrap.min.css";
import "./Footer.css";
import img1 from '../../assets/image/gl-1.jpg'
import img2 from '../../assets/image/gl-2.jpg'
import img3 from '../../assets/image/gl-3.jpg'
import img4 from '../../assets/image/gl-4.jpg'
import img5 from '../../assets/image/gl-5.jpg'
import img6 from '../../assets/image/gl-6.jpg'

const Footer = () => {
  return (
    <footer className="footer bg-dark text-white pt-5 pb-4">
      <div className="container">
        <div className="row">
          {/* Charity Section */}
          <div className="col-md-3">
            <h5 className="mb-4">CHARITY</h5>
            <p className="small-text">
              Tincidunt luctus porta amet lectus at ultricies nec sed non. Sed
              sit egestas enim consectetur donec faucibus...
            </p>
            <p>
              <strong>Phone:</strong> +92 318 7986136
            </p>
            <p>
              <strong>Address:</strong> Gujranwala
              <br />
              Pakistan
            </p>
            {/* Social Media Icons */}
            <div className="social-icons mt-3">
              <a href="#" className="social-icon">
                <i className="bi bi-facebook"></i>
              </a>
              <a href="#" className="social-icon">
                <i className="bi bi-twitter"></i>
              </a>
              <a href="#" className="social-icon">
                <i className="bi bi-instagram"></i>
              </a>
            </div>
          </div>

          {/* About Us Section */}
          <div className="col-md-3">
            <h5 className="mb-4">About Us</h5>
            <ul className="list-unstyled">
              <li>
                <a href="#" className="footer-link">
                  About Us
                </a>
              </li>
              <li>
                <a href="#" className="footer-link">
                  Causes
                </a>
              </li>
              <li>
                <a href="#" className="footer-link">
                  Volunteers
                </a>
              </li>
              <li>
                <a href="#" className="footer-link">
                  Partners
                </a>
              </li>
              <li>
                <a href="#" className="footer-link">
                  Contact Us
                </a>
              </li>
            </ul>
          </div>

          {/* Useful Links Section */}
          <div className="col-md-3">
            <h5 className="mb-4">Useful Links</h5>
            <ul className="list-unstyled">
              <li>
                <a href="#" className="footer-link">
                  F.A.Q
                </a>
              </li>
              <li>
                <a href="#" className="footer-link">
                  News
                </a>
              </li>
              <li>
                <a href="#" className="footer-link">
                  Reports
                </a>
              </li>
              <li>
                <a href="#" className="footer-link">
                  Terms of Use
                </a>
              </li>
              <li>
                <a href="#" className="footer-link">
                  Privacy Policy
                </a>
              </li>
            </ul>
          </div>

          {/* Causes Section */}
          <div className="col-md-3">
            <h5 className="mb-4">Causes</h5>
            <div className="row g-2">
              <div className="col-4">
                <img
                  src={img1}
                  alt="Cause 1"
                  className="img-fluid rounded cause-img"
                />
              </div>
              <div className="col-4">
                <img
                  src={img2}
                  alt="Cause 2"
                  className="img-fluid rounded cause-img"
                />
              </div>
              <div className="col-4">
                <img
                  src={img3}
                  alt="Cause 3"
                  className="img-fluid rounded cause-img"
                />
              </div>
              <div className="col-4">
                <img
                  src={img4}
                  alt={img4}
                  className="img-fluid rounded cause-img"
                />
              </div>
              <div className="col-4">
                <img
                  src={img5}
                  alt={img5}
                  className="img-fluid rounded cause-img"
                />
              </div>
              <div className="col-4">
                <img
                  src={img6}
                  alt={img6}
                  className="img-fluid rounded cause-img"
                />
              </div>
            </div>
          </div>
        </div>

        {/* Footer Bottom Section */}
        <div className="row mt-4">
          <div className="col text-center small-text">
            &copy; Copyright Charity 2025. Design by SkCoder
          </div>
        </div>
      </div>
    </footer>
  );
};

export default Footer;
