import React, { useState } from "react";
import "./style.css";
import img1 from '../../assets/image/gl-1.jpg'
import img2 from '../../assets/image/gl-2.jpg'
import img3 from '../../assets/image/gl-3.jpg'
import img4 from '../../assets/image/gl-4.jpg'
import img5 from '../../assets/image/gl-5.jpg'
import img6 from '../../assets/image/gl-6.jpg'
import img7 from '../../assets/image/gl-7.jpg'
import img8 from '../../assets/image/gl-8.jpg'
import img9 from '../../assets/image/gl-9.jpg'
import img10 from '../../assets/image/gl-10.jpg'
import img11 from '../../assets/image/gl-11.jpg'

function Gallery() {
  const [modalImage, setModalImage] = useState(null);

  const images = [
    img1,
    img2,
    img3,
    img4,
    img5,
    img6,
    img7,
    img8,
    img9,
    img10,
    img11,
  ];

  const openModal = (image) => {
    setModalImage(image);
  };

  const closeModal = () => {
    setModalImage(null);
  };

  return (
    <>
      <div className="container main__gallery">
        <center>
        <div className="gallery__header-wrapper">
          <h2 className="gallery__header">Gallery</h2>
        </div>
        </center>
        <div className="row g-3">
          {images.map((image, index) => (
            <div className="col-md-3 col-sm-4" key={index}>
              <img
                src={image}
                alt={`Gallery Item ${index + 1}`}
                className="img-fluid gallery__image"
                onClick={() => openModal(image)}
                style={{ cursor: "pointer" , height: "auto", width : "100%"}}
              />
            </div>
          ))}
        </div>
      </div>

      {modalImage && (
        <div className="modal show d-block" tabIndex="-1" onClick={closeModal}>
          <div
            className="modal-dialog modal-lg modal-dialog-centered"
            onClick={(e) => e.stopPropagation()}
          >
            <div className="modal-content">
              <div className="modal-header">
                <h5 className="modal-title">Gallery Image</h5>
                <button
                  type="button"
                  className="btn-close"
                  aria-label="Close"
                  onClick={closeModal}
                ></button>
              </div>
              <div className="modal-body">
                <img
                  src={modalImage}
                  alt="Modal Content"
                  className="img-fluid modal-image"
                />
              </div>
            </div>
          </div>
        </div>
      )}
    </>
  );
}

export default Gallery;
