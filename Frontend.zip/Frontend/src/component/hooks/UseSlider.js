import { useEffect } from 'react';

const useSlider = (slideImage, slideText, images) => {
  let slideCounter = 0;

  useEffect(() => {
    startSlider();
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, []);

  const startSlider = () => {
    if (images.length > 0) {
      slideImage.current.style.backgroundImage = `linear-gradient(
        to right,
        rgba(34, 34, 34, 0.4),
        rgba(68, 68, 68, 0.4)
      ), url(${images[0].src})`;
      slideText.current.innerHTML = images[0].text;
    }
  };

  const handleSlide = (slide) => {
    if (images.length > 0) {
      slideImage.current.style.backgroundImage = `linear-gradient(
        to right,
        rgba(34, 34, 34, 0.4),
        rgba(68, 68, 68, 0.4)
      ), url(${images[slide - 1].src})`;
      slideText.current.innerHTML = images[slide - 1].text;
      animateSlide();
    }
  };

  const animateSlide = () => {
    slideImage.current.classList.add('fadeIn');
    setTimeout(() => {
      slideImage.current.classList.remove('fadeIn');
    }, 700);
  };

  const goToPreviousSlide = () => {
    if (slideCounter === 0) {
      slideCounter = images.length;
    }
    slideCounter--;
    handleSlide(slideCounter);
  };

  const goToNextSlide = () => {
    if (slideCounter === images.length - 1) {
      slideCounter = -1;
    }
    slideCounter++;
    handleSlide(slideCounter);
  };

  return { goToPreviousSlide, goToNextSlide };
};

export default useSlider;
